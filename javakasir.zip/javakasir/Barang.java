package javakasir;
public class Barang {
    int id;
String namaBarang;
int stockBarang, hargaBarang, terjual;


public Barang(int id, String namaBarang, int stockBarang, int hargaBarang, int terjual){
        this.id = id;
        this.namaBarang  = namaBarang;
        this.stockBarang = stockBarang;
        this.hargaBarang = hargaBarang;
        this.terjual = terjual;
    }          
}